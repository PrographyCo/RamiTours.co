<?php

$_SESSION['qeema_admin'] = 'none';

echo $_SESSION['qeema_admin'];