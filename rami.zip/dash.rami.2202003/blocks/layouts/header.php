<header>
    <div class="header-top " style="z-index:4">
        <div class="container-fluid h-100" style="position:absolute;">

            <div class="main  mt-md-4 mx-auto mx-md-auto mx-xl-0  col-9 col-md-6 col-xl-5 justify-content-center">

                <!-- Actual search box -->
                <div class="form-group has-search" >
                    <span class="fa fa-search form-control-feedback"></span>
                    <input type="text" class="form-control form-control-lg" placeholder="Search" id="search">
                </div>



            </div>

    </div>

</header>

