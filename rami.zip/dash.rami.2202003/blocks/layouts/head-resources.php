<link rel="stylesheet" href="assets/css/plugins.css">
<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" integrity="sha384-KA6wR/X5RY4zFAHpv/CnoG2UW1uogYfdnP67Uv7eULvTveboZJg0qUpmJZb5VqzN" crossorigin="anonymous">

<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
<link rel="stylesheet" href="assets/css/swiper.min.css">

<link rel="icon" href="assets/images/icon.png" type="image/png" sizes="15x15">

<style>
    .nav-item:hover div .logo__txt
    {
        filter : contrast(1) !important;
        transition: 1s;
    }
    .nav-item:hover div img
    {
        filter : contrast(1) !important;
        transition: 1s;
    }
</style>