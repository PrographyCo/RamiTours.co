<div class="mobile-menu">



                <ul class="  list-unstyled  my-auto text-center ">
                    <li class="active "><a href="#home-section" target="" class="text-primary px-1 px-xl-2 px-lg-1 font-weight-bold  ">Home</a></li>
                    <li><a href="#aboutus" target="" class="px-xl-2 px-lg-1">About Us</a></li>
                    <li><a href="#services" target="" class="px-xl-2 px-lg-1"> Services</a></li>
                    <li><a href="#portfolio" target="" class=" px-1 px-xl-2 px-lg-1">Portfolio</a></li>
                    <li><a href="#clients" target="" class="px-xl-2 px-lg-1">Clients</a></li>
                    <li><a href="#contactus" target="" class="px-xl-2 px-lg-1">Contact Us</a></li>
                    <li><a href="" target="" class="px-xl-2 px-lg-1 mr-0">Arabic</a></li>
                    <li class="ml-2 d-flex mx-auto justify-content-center " >

                        <a href="#" class="facebook "><i class="fab fa-facebook-f "></i></a>
                        <a href="#" class="twitter "><i class="fab fa-twitter"></i></a>
                       <a href="#" class="youtube "><i class="fab fa-youtube"></i></a>
                        <a href="#" class="linkedin-in "><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="instagram "><i class="fab fa-instagram"></i></a>
                        <a href="" class="behance "> <i class="fab fa-behance"></i></a>

                        </li>


                </ul>




</div>