<div class="loader" style="position: fixed; top: 0; background: #FFF5EB; display: flex; justify-content: center; align-items: center; z-index:99999;">
    <img src="<?= IMG ?>loader.png" alt="loader" style="width: 10%; animation: rotate 2s infinite;" />
</div>