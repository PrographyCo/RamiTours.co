<!doctype html>
<html>
    <head>
        <meta charset="UTF-8" >
        <title><?= $title; ?></title>
        <link rel="icon" href="<?= IMG ?>logo-icon2.png" type="image/png" sizes="17x17">
        <meta name="viewport" content="width=device-width, initial-scale=1" >
