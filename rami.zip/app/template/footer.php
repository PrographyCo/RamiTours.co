<footer class="main-footer w-100  " >
    <div class="container w-100">

        <div class="  copy  mt-n4 text-center text-white   ">
            <?= $copy; ?> <a href="https://prography.co " class="text-white">Prography</a>
            <span id="year"></span>
            <?= $with; ?>
            <a href="https://<?= $link->link; ?>" class="text-white">Apex lions</a>
        </div>
    </div>
</footer>