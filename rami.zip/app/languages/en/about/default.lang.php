<?php

$_['title'] = 'Ramitours';

$_['home'] = 'Home';
$_['about'] = 'About Us';
$_['serv'] = 'Services';
$_['cont'] = 'Contact Us';

$_['aboutp'] = 'Business, Pleasure or Private Guided Tours If you’re looking to Book a Minibus or
                        Coach hire with driver in Israel,If you’re looking for luxury transportation
                        with a courteous Christian based guide service, then look no further than Rami Tours & Transportation.';

$_['vc'] = 'Visitor\'s Comments';

$_['name'] = 'Full Name';
$_['email'] = 'Email';
$_['message'] = 'The Text Of Message';
$_['require'] = 'All fields are required';
$_['send'] = 'Send';

$_['copy'] = 'Copyright &copy; All rights reserved,';
$_['with'] = 'with';


$_['lang'] = 'en';