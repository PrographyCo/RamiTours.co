<?php

$_['title'] = 'Ramitours';

$_['home'] = 'Home';
$_['about'] = 'About Us';
$_['serv'] = 'Services';
$_['cont'] = 'Contact Us';

$_['s1img'] = IMG.'s6.jpg';
$_['s1h1'] = 'Rami Tours & Transportation ';
$_['s1p'] = '  Business, Pleasure or Private Guided Tours';

$_['s2img'] = IMG.'s2.jpg';
$_['s2h1'] = 'Rami Tours & Transportation ';
$_['s2p'] = 'Business, Pleasure or Private Guided Tours';

$_['s3img'] = IMG.'s3.jpg';
$_['s3h1'] = 'Rami Tours & Transportation ';
$_['s3p'] = 'Business, Pleasure or Private Guided Tours';

$_['copy'] = 'Copyright &copy; All rights reserved,';
$_['with'] = 'with';