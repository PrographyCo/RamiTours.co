<?php

$_['title'] = 'Ramitours';

$_['home'] = 'Home';
$_['about'] = 'About Us';
$_['serv'] = 'Services';
$_['cont'] = 'Contact Us';



$_['copy'] = 'Copyright &copy; All rights reserved,';
$_['with'] = 'with';