<?php

$_['title'] = 'Ramitours';

$_['home'] = 'Home';
$_['about'] = 'About Us';
$_['serv'] = 'Services';
$_['cont'] = 'Contact Us';


$_['name'] = 'Full Name';
$_['email'] = 'Email';
$_['message'] = 'The Text Of Message';
$_['require'] = 'All fields are required';
$_['send'] = 'Send';

$_['media'] = 'For Media';
$_['whats'] = 'Whatsapp';
$_['face'] = 'Facebook';

$_['copy'] = 'Copyright &copy; All rights reserved,';
$_['with'] = 'with';


$_['lang'] = 'en';