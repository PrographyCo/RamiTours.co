<?php

namespace MVC\Controllers;

class NotFoundController extends AbstractController
{

}