<div class="services">
    <div class="container ">

        <div class="page-title mb-3 text-center">
            <h1>
                <?= $serv ?>
            </h1>
        </div>


        <div class="text pb-5 animated slideInUp delay-.2ms">
            <?= $services->link ?>
        </div>
    </div>



</div>

